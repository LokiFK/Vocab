module Vocab {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.desktop;

    opens controller;
}